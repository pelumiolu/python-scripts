total=0
def find(alist):        #you could also do this with try and except.                
    for newlist in alist:
        if ch in d:
            total+= d[char]
##for item in d1:
##    if item in d2:
##
##    else:
        
    
    
mydict = {}
for letter in "hello":
    for character in "world":
        mydict[letter] = character
print(len(mydict))

print(mydict['h'])
