def eat(foodInFridge, cravings):
    final_tup=()
    for food in foodInFridge:
        for new_crav in cravings:
            if food.upper()== new_crav.upper():
                final_tup+= (food,)
    return final_tup

foodInFridge = ("expired milk", "apples", "LeftoverS")
cravings = ("cheese", "leFTOvers")
print(eat(foodInFridge, cravings))
        
