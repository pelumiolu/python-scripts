def makecopy(list):
    return list.append(list)

 def add_to(list):
     for index in range(len(words)):
         words[index]+="s"
    print(words)
