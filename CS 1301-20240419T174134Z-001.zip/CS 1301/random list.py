
final_list=""
def merge3(list1, list2, list3):
    for place in len(list1):
        new_list=list1[place] + list2[place] + list3[place]
        final_list+= new_list.append()
    return new_list
print(merge3([1,2,3],['a','b','c'],[4,5,6]))
