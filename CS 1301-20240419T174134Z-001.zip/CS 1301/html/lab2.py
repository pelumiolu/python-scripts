"Lab 2 Python Functions"
"Created by Pelumi Oluleye"
"__collab statement__: I worked on the homework assignment alone, using only this semester's course materials."

import json
import requests
from pprint import pprint

"What was the average amount of wind for each month?"

def wind_rate(filename):
    fh= open(filename,"r")
    headings= fh.readline()
    data= fh.readlines()
    fh.close()
    
    alist=[]
    new_dict={}
    for datalines in data:
        info = datalines.split(",")
        new_tup= info[2],info[10]
        alist.append(new_tup)
    for tup_list in alist:
        new_dict[tup_list[0]]= []
    for tup_list in alist:
        if tup_list[1] != '':
            new_dict[tup_list[0]].append(tup_list[1])
    for key in new_dict:
        sum_num=0
        num_list= new_dict[key]
        for num in num_list:
            sum_num+= int(float(num))
            avg_val=round(sum_num/len(num_list),2)
            new_dict[key]= avg_val
    return new_dict

   

"Which month is the most prominent for forest fires?"
def worst_month(filename):
    fh= open(filename,"r")
    headings= fh.readline()
    data= fh.readlines()
    fh.close()
    
    alist=[]
    new_dict={}
    for datalines in data:
        info = datalines.split(",")
        new_tup= info[2],info[10]
        alist.append(new_tup)
    for tup_list in alist:
        new_dict[tup_list[0]]= []
    for tup_list in alist:
        if tup_list[1] != '':
            new_dict[tup_list[0]].append(tup_list[1])
    for key in new_dict:
        sum_num=0
        num_list= new_dict[key]
        for num in num_list:
            instances=len(num_list)
            new_dict[key]= instances
    return new_dict


"Which month has the highest FFMC for each month? This was there can be ways researched to determine how to prevent forest fires that recure prominently?"

def fire_fuel(filename):
    fh= open(filename,"r")
    headings= fh.readline()
    data= fh.readlines()
    fh.close()
    
    alist=[]
    new_dict={}
    for datalines in data:
        info = datalines.split(",")
        new_tup= info[2],info[4]
        alist.append(new_tup)
    for tup_list in alist:
        new_dict[tup_list[0]]= 0
    
    for tup_list in alist:
        if tup_list[1] != '':
            max_value=0
            if int(float(tup_list[1])) > max_value:
                max_value= int(float(tup_list[1]))
                new_dict[tup_list[0]]= max_value
    return new_dict

    

"Determine the top three post types users on Facebook interact with?"

def find_interactions(filename):
    my_file = open(filename, "r")
    json_string = my_file.read()
    my_dict = json.loads(json_string)
    my_file.close()
    
    adict= my_dict['data']
    info_list=[]
    new_dict={}
    tup_list=[]
    top_three=[]
    for place in range(len(adict)):
        interaction=adict[place]['Total Interactions']
        post_type= adict[place]['Type']
        new_tup= interaction,post_type
        info_list.append(new_tup)
    for single_tup in info_list:
        new_dict[single_tup[1]]= 0
    for single_tup in info_list:
        new_dict[single_tup[1]]= new_dict[single_tup[1]] + single_tup[0]
    for key,item in new_dict.items():
        dict_tup=item,key
        tup_list.append(dict_tup)
        tup_list.sort(reverse=True)
    for post in tup_list:
        top_three.append(post) 
    return top_three[0:3]

        
        

"When is the best hour for the cosmetic company to post?"
def best_hour(filename):
    my_file = open(filename, "r")
    json_string = my_file.read()
    my_dict = json.loads(json_string)
    my_file.close()
    
    adict= my_dict['data']
    info_list=[]
    max_value= 0
    new_dict={}
    for place in range(len(adict)):
        num_likes=adict[place]['like']
        hour= adict[place]['Post Hour']
        new_tup= num_likes,hour
        info_list.append(new_tup)
    for single_tup in info_list:
        new_dict[single_tup[1]]= 0
    for single_tup in info_list:
        if single_tup[0] != '':
            max_value=0
            if int(single_tup[0]) > max_value:
                max_value= int(single_tup[0])
                new_dict[single_tup[1]]= max_value
    return new_dict



"What is the average number of likes on a post and the type?"
def avg_post(filename):
    my_file = open(filename, "r")
    json_string = my_file.read()
    my_dict = json.loads(json_string)
    my_file.close()

    adict= my_dict['data']
    info_list=[]
    dict_list=[]
    new_dict={}
    key_list=[]
    for place in range(len(adict)):
        num_likes=adict[place]['like']
        post_type= adict[place]['Type']
        new_tup=num_likes,post_type
        info_list.append(new_tup)
    for single_tup in info_list:
        new_dict[single_tup[1]]= []
    for single_tup in info_list:
        if single_tup[0] != '':
            new_dict[single_tup[1]].append(single_tup[0])
    for key in new_dict:
        sum_num=0
        num_list= new_dict[key]
        for num in num_list:
            sum_num+= num
            avg_val=round(sum_num/len(num_list),2)
            new_dict[key]= avg_val
    return new_dict



