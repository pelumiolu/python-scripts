def retrieve(fname, numlist):
    openfile=open(fname, "r")
    file_new=openfile.read()
    new= file_new.split()
    for place in numlist:
        print(new[place-1])
    openfile.close()




    
    
