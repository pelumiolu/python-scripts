count=0
def swap_names(tup_list):
    for item in tup_list:
        return (item[1]+ "," +item[0]+count)
    count+=1
