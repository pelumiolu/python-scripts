"""
Georgia Institute of Technology - CS1301
HW07 - APIs and JSON
"""
__author__ = """ Pelumi Oluleye """
__collab__ = """ I worked on this homework with Amran Mamuye and Keah Gruduah using only course materials. """

import requests
from pprint import pprint


def currencyConverter(country, money, conversionFactor):
    url='https://restcountries.eu/rest/v2'
    web_data= requests.get(url)
    data= web_data.json()
    for num in range(len(data)):
        if data[num]['name'].lower() == country.lower():
            code=data[num]['currencies'][0]['code']
            new_money= round(float(money*conversionFactor),2)
            foreign_symbol= data[num]['currencies'][0]['symbol']
            return 'In {}, ${} USD is worth {}{} {}.'.format(country,money,foreign_symbol,new_money, code)
        for place in range(len(data[num]['altSpellings'])):
            if data[num]['altSpellings'][place].lower()== country.lower():
                code=data[num]['currencies'][0]['code']
                new_money= round(float(money*conversionFactor),2)
                foreign_symbol= data[num]['currencies'][0]['symbol']
                return 'In {}, ${} USD is worth {}{} {}.'.format(country,money,foreign_symbol,new_money, code)
            
    return '{} is not a valid country.'.format(country)
                                                         


def translator(codeList):
    url='https://restcountries.eu/rest/v2'
    web_data= requests.get(url)
    data= web_data.json()
    new_dic= {}
    for country in codeList:
        c=country.upper()
        for num in range(len(data)):
            x=data[num]['cioc']
            if x== c:
                country_name= data[num]['nativeName']
                dic_key= data[num]['name']
                new_dic[dic_key]= country_name
    return new_dic
        



def nearbyLocations(codeList):
    url='https://restcountries.eu/'
    max_value=-5000
    new_list=[]
    final_list=[]
    for place in codeList:
        new_url= "{}{}{}".format(url,"rest/v2/alpha/",str(place))
        web_data= requests.get(new_url)
        data= web_data.json()
        if "message" not in data:
            country_amount= len(data['borders'])
            if country_amount> max_value:
               max_value= country_amount  
    for place in codeList:
        new_tup=()
        new_url= "{}{}{}".format(url,"rest/v2/alpha/",str(place))
        web_data= requests.get(new_url)
        data= web_data.json()
        if len(data['borders'])== max_value:
            new_tup=(data['name'],data['borders'])
            new_list.append(new_tup)
    new_list.sort(reverse=True)
    for area in new_list[0][1]:
        ntup=()
        new_url= "{}{}{}".format(url,"rest/v2/alpha/",str(area))
        web_data= requests.get(new_url)
        data= web_data.json()
        lnl=data['latlng']
        ntup+= lnl[0],lnl[1]
        final_list.append(ntup)
    return final_list

   

def humidityCheck(locationsList, maxHumidity):
    url="http://api.openweathermap.org/data/2.5/weather?"
    web_data= requests.get(url)
    data= web_data.json()
    new_list=[]
    try:
        for place in locationsList:
            new_url= url+ "id="+str(place)+'&APPID=1448cd34e707cd159ddb2b40195b3ccb'
            new_web= requests.get(new_url)
            new_data= new_web.json()
            if new_data['main']['humidity'] < maxHumidity:
                location= new_data['name']
                new_list.append(location)
    except:
        return '{} is not a valid ID'.format(place)
    return new_list



def locationTemps(coordinatesList):
    url="http://api.openweathermap.org/data/2.5/weather?"
    web_data= requests.get(url)
    data= web_data.json()
    new_tup=()
    new_list=[]
    for item in coordinatesList:
        lat=item[0]
        lon=item[1]
        new_url= url+"lat="+str(lat)+"&lon="+str(lon)+"&APPID=1448cd34e707cd159ddb2b40195b3ccb"
        new_web=requests.get(new_url)
        new_data= new_web.json()
        new_tup= new_data['name'], new_data['main']['temp']
        new_list.append(new_tup)
        new_list.sort( key = lambda x: x[1])  
    return new_list



def typesOfWeather(locationsList):
    url="http://api.openweathermap.org/data/2.5/weather?"
    new_dict={}
    for place in locationsList:
        new_url= url+ "id="+str(place)+'&APPID=1448cd34e707cd159ddb2b40195b3ccb'
        new_web= requests.get(new_url)
        new_data= new_web.json()
        if 'message' not in new_data:
            new_dict[new_data['weather'][0]['main']]= []
        else:
            return '{} is not a valid ID'.format(place)
    for place in locationsList:
        new_url= url+ "id="+str(place)+'&APPID=1448cd34e707cd159ddb2b40195b3ccb'
        new_web= requests.get(new_url)
        new_data= new_web.json()
        if 'message' not in new_data:
            if new_data['weather'][0]['main'] in new_dict:
                new_dict[new_data['weather'][0]['main']].append(new_data['name'])
    return new_dict
