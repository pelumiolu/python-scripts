from rate import add 
from rate import subtract 
from rate import multiply 
from rate import divide 
"""
Georgia Institute of Technology - CS1301
HW05 - Tuples and Modules
"""
__author__ = """ Pelumi Oluleye """
__collab__ = """ I worked on this homework with Keah Gruduah using course materials."""



def yelp_rating(original_rating,num, operation):
    if operation == "+":
        return round(add(original_rating, num),1)
    elif operation == "-":
        return round(subtract(original_rating, num),1)
    elif operation == "*":
        return round(multiply(original_rating, num),1)
    elif operation == "/":
        return round(divide(original_rating, num),1)

def register_passport(info):
    info=info.split(": ")
    num_place= info[1]
    num_place=num_place.split(", ")
    return(num_place[1],info[0],int(num_place[0]))


def location_ideas(places):
    reverse_tup=[]
    final_tup=()
    for info in places:
        reverse_tup.append(info[1])
    for place in range(len(places)):
        minimum= reverse_tup.index(min(reverse_tup))
        final_tup+= (places[minimum][0],)
        reverse_tup[minimum]= reverse_tup[minimum]*max(reverse_tup)
    return final_tup
        



def find_airbnb(homes,people,price):
    created_list=[]
    for info in homes:
        (name,capacity,rating,price_per_night)=info
        if capacity >= people and price_per_night <= price:
            created_list.append(info)
    maximum= 0
    new_tup=()
    for check in created_list:
        if check[2]>= maximum:
            maximum=check[2]
            new_tup+= check
    if new_tup==():
        return ()
    return (new_tup[0], round(new_tup[3]/people, 2))


def travel_buddy(names):
    names=names.split("; ")
    numbers=[]
    for place in range(len(names)):
        pieces= names[place]
        pieces=pieces.split(",")
        numbers.append((pieces[0], int(pieces[1]))) 
    maximum=0
    for top in numbers:
        if top[1] >= maximum:
            maximum=top[1]
            final= top
    return final

 

def remove_ingredients(recipe, allergylist):
    good_ingredients=[]
    upperAllergy = []
    for allergy in allergylist:
        upperAllergy.append(allergy.upper())
    for ingredients in recipe:
        newTup = ()
        for good_ones in ingredients:
            if good_ones.upper() not in upperAllergy:
                newTup += (good_ones,)
        good_ingredients.append(newTup)
    return good_ingredients




 
 
