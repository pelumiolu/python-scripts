"""
Georgia Institute of Technology - CS1301
HW08 - File I/O
"""
__author__ = """ Pelumi Oluleye """
__collab__ = """ I worked on this homework alone """

def get_roster(filename):
    try:
        fh= open(filename, "r")
        file= fh.read()
        fh.close()
        name_list=[]
        new_list= file.split("\n")
        for entire_list in new_list:
            if "," in entire_list:
                name_list.append(entire_list)
                
        new_tup=()
        all_names=[]
        for names in name_list:
            names=names.split(",")
            new_tup= names[0],names[1]
            all_names.append(new_tup)
        return all_names
    except FileNotFoundError:
        return "File not found."

    


def get_average(filename,student):
    roster_list=[]
    stu_1=""
    grades_list=[]
    s_t=student.split()
    grades=0
    for name in s_t:
        stu_1+=name +", "
    stu_2= stu_1[:len(stu_1)-2]
    try:
        fh=open(filename, "r")
        lines= fh.readlines()
        fh.close()
        for place in lines:
            place= place.replace("\n", "")
            roster_list.append(place)
        roster_list.append("")
        if stu_2 not in roster_list:
            return "Student not found in file."
        else:
            for new_place in roster_list:
                if new_place == stu_2:
                    item= roster_list.index(new_place)
                    roster_list= roster_list[item:]
            a_place= roster_list.index("")
            roster_list= roster_list[:a_place]
            for score in roster_list[1:]:
                score_place= score.find(": ")
                grades_list.append(score[score_place+2:])
            for num in grades_list:
                grades+= float(num)
            grades_average= round(grades/len(grades_list), 2)
            return student,grades_average
    except FileNotFoundError:
        return "File is not found."


                            
                                    

"""
Function name: get_all_averages
Parameters: filename (string)
Returns: A dictionary representing a student as the key,
and their average on exams as the value
Description: Read in a file of any name but in the format as what is stated
above. For every student, make an entry in a dictionary where their first
name is the key and their average for their exams as the value. The file will
not have duplicate first names. The average will be a float rounded to two
decimals. If the file is not found, catch a FileNotFoundError and return
“File is not found.” 
"""
def get_all_averages(filename):
    try:
        new_dict={}
        roster= get_roster(filename)
        for names in roster:
            name= "{} {}".format(names[0], names[1])
            grad_avg= get_average(filename,name)
            new_dict[name]= grade_avg[1]
        return new_dict
    
    except FileNotFoundError:
        return "File nost found."
print(get_all_averages("students.txt")) 



"""
Function name: form_groups
Parameters: filename (string), current_student (string), num_per_team (int)
Returns: None
Description: Read in a file of any name but in the format as what is stated
above. If the file is not found, catch a FileNotFoundError and return
“File is not found.”. In a new file to write named group.txt, write
“Team StudentName” on one line, replacing StudentName with the name of the
current student passed in. Go through the file to find the top X-1 number
of students to add to your team, top being those with the highest averages.
X is the number passed in representing the maximum number of people per team,
and X-1 is the number of students selected on the team minus the current
student. The current student can not be one of the students added to the team.
If there are less than X number of students, then everyone in the file is
included on the team. However, the number of students in a team can not exceed
X. If X == 1, then just write the header on the file “Team StudentName”
and if X == 0, then do not write anything to the file. There will not be more
than one student with the same average. Each of these students will be a
separate line in the new file in the format of “Y) Student Name”, Y being a
number in a list in increasing order, going from 1 - the maximum number of
people per team. The top student will be 1, and then it will go down in
decreasing top scores. The last line of the file should not have a “\n”.
This function will return None unless there is an error.
"""
def form_groups(filename, current_student, num_per_team):
    fh= open(filename, "r")
    file= fh.read()
    writeFile= open(filename, "w")
    writeFile.write("Team {}".format(current_student))
    student_list= get_all_averages
    new_tup=()
    for name, average in student_list.items():
        new_tup= name,average
    fh.close()
    return "Team {} \n1){} \n2){}".format(new_tup)
    

def zero_calorie_diet(filename):
    try:
        fh= open(filename, "r")
        headings= fh.readline()
        datalines= fh.readlines()
        fh.close()
        max_cal=100000000
        for line in datalines:
            info = line.split(",")
            if int(info[2]) < max_cal:
                max_cal= int(info[2])
        for line in datalines:
            info = line.split(",")
            if int(info[2]) == max_cal:
                good_food= info[0]
        return good_food
    except FileNotFoundError:
        return "File not found."


def erica_menu(filename, num_of_dishes):
    try:
        fh= open(filename, "r")
        headings= fh.readline()
        datalines= fh.readlines()
        fh.close
        ideal_menu=[]
        if num_of_dishes == 0:
            best_menu=open("EricaMenu.txt", "w")
            best_menu.write("Erica's Menu")
            best_menu.close()
        else:
            good_tup=()
            for line in datalines:
                info = line.split(",")
                if "Vegetarian" not in info[3]:
                    food= info[0]
                    price=float(info[1][1::])
                    food_type= info[3][:-1].strip(" ")
                    good_tup= food,price,food_type
                    ideal_menu.append(good_tup)
            ideal_menu.sort( key = lambda x: x[1])
            best_menu=open("EricaMenu.txt", "w")
            best_menu.write("Erica's Menu")
            for menu in ideal_menu:
                for num in range(num_of_dishes-2):
                    food_item= "\n{}, ${}, {}".format(menu[0],menu[1],menu[2])
                best_menu.write(food_item)
            best_menu.close()
        
    except FileNotFoundError:
        return "File not found."
