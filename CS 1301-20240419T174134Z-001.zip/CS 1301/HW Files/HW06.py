
"""
Georgia Institute of Technology - CS1301
HW06 - TRY/EXCEPT & DICTIONARIES
"""
__author__ = """ Pelumi Oluleye """
__collab__ = """ I completed this homework on my own using only course materials. """


def make_gamertag(words,alist):
    gamertag=""
    for place in alist:
            try:
               gamertag+=words[place] + "x"
            except:
                gamertag+="0"
    return "[{}]".format(gamertag)
                



def split_the_loot(adict,items,cash,burglars):
    treasure=""
    want=""
    money=0
    for objects in items:
        treasure+= objects.upper()
    for name in items:
        want+= name

    for keys in adict:
        try:
            if keys in want:
                money+= adict[keys]
            elif keys.upper() in treasure.upper():
                money+= 0
        except:
            return "TypeError"
    if money+cash <0:
        return "Negative"
    elif burglars <=0:
        return "BurglarError"    
    return round(float((money+cash)/burglars),2)



def football_stars(dict1, dict2):
    final_dict={}
    for name,player in dict2.items():
        for locations,teams in dict1.items():
            if name in teams:
               final_dict[player]= locations, name
    return final_dict


def pair_rivals(dict1,dict2):
    rival_pair={}
    for rival in dict1.keys():
        for rival2 in dict1.keys():
            if rival == dict1[rival2] and (rival2, rival) not in rival_pair:
                rival_pair[(rival, rival2)]=True
        for new_char in dict2.keys():
            if rival == dict2[new_char]:
                rival_pair[(rival, new_char)]= True
    return rival_pair
    


def zoo_keeper(zoo):
    animals={}
    for zoo1 in zoo:
        animal_type,nom,quantity=zoo1
        if animal_type not in animals:
            animals[animal_type]={nom:quantity}
        else:
            if nom not in animals[animal_type]:
                animals[animal_type][nom]= quantity
            else:
                animals[animal_type][nom]+= quantity
    return animals



def animal_locator(dict1):
    keyList = []
    tupList = []
    newdict={}
    for location in dict1:
        for animal,number in dict1[location]:
            group= (number, animal ,location)
            tupList.append(group)
            if animal not in keyList:
                keyList.append(animal)
    tupList.sort(reverse=True)
    for key2 in keyList:
        locationlist = []
        total=0
        for data in tupList:
            if key2 == data[1]:
                if data[2] not in locationlist:
                    locationlist.append(data[2])
                    total+=data[0]
        newdict[key2]= (locationlist,total)
    return newdict
                
                      
        
