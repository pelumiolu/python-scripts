
##Georgia Institute of Technology - CS1301
##HW02 - Return and Conditionals
##"""
##__author__ = """ Pelumi Oluleye """
##__collab__ = """ I worked on this homework with Afua Kessie and Keah Gruduah and referred to my course materials."""



def can_buy(ticker, wallet, shares):
    if wallet>= (shares*23.98) and ticker.upper()=="AMD":
        return True
    elif wallet < (shares*23.98) and ticker.upper()=="AMD":
        return False
    elif wallet>= (shares*79.62) and ticker =="XOM":
        return True
    elif wallet<(shares*79.62) and ticker.upp()=="XOM":
        return False
    elif wallet>= (shares*322.82) and ticker.upper()=="TSLA":
        return True
    elif wallet<(shares*322.82) and ticker.upper()=="TSLA" :
        return False
    elif wallet>= (shares*11.63) and ticker.upper()=="SNAP" :
        return True
    elif wallet< (shares*11.63) and ticker.upp()=="SNAP":
        return False
    else: 
        return None
    


def amount_spent(ticker, wallet, shares):
    if can_buy(ticker, wallet, shares)== True:
        if ticker.upper() =="AMD":
            return round(float(shares*23.98),2)
        elif ticker.upper() =="XOM":
            return round(float(shares*79.62),2)
        elif ticker.upper() =="TSLA":
            return round(float(shares*322.82),2)
        elif ticker.upper() == "SNAP":
            return round(float(shares*11.63),2)
    



def good_buy(ticker):
    if ticker.upper()== "AMD":
        trend="up"
        reversal=True
        if trend=="up" and reversal==False or trend=="down" and reversal==True:
            return True
        else:
            return False
    elif ticker.upper()=="XOM":
        trend= "down"
        reversal= False
        if trend=="down" and reversal==True or trend=="up" and reversal==False:
            return True
        else:
            return False
    elif ticker.upper()=="TSLA":
        trend= "up"
        reversal= False
        if trend=="up" and reversal==False or trend=="down" and reversal==True:
            return True
        else:
            return False
    elif ticker.upper()=="SNAP":
        trend= "down"
        reversal= True
        if trend=="down" and reversal==True or trend=="down" and reversal==True:
             return True
        else:
                return False
    


def warren_buffet_boy(ticker,shares):
    if ticker.upper()=="AMD":
        industry= "Semiconductor"
    elif ticker.upper()=="XOM":
        industry= "Energy"
    elif ticker.upper()=="TSLA":
        industry= "Automotives"
    elif ticker.upper()=="SNAP":
        industry= "Technology"
    if good_buy(ticker):
        if industry == "Semiconductor" or industry== "Technology":
            if shares<500:
                    print("Warren Buffett wouldn't waste his time with {}.".format(shares))
            else:
                if amount_spent:
                    print("Warren Buffett would have ${} remaining after buying {} shares of {}.".format(1000000-amount_spent(ticker,1000000,shares),shares,ticker))
        else:
         print("{} does not meet Warren Buffett's industry standards.".format(ticker))
    else:
        print("{} does not meet basic 'good buy' standards.".format(ticker))
        


def temperature(temp):
    if temp>=90:
        return  "It’s over 9,000!!!"
    elif temp<90 and temp>=75:
        return "Can it stay like this?"
    elif temp<75 and temp>=40:
        return "Okay not too low now."
    elif temp<40 and temp>=32:
        return "Can it be 90 again?"
    else:
        return "We’re in Georgia not Antarctica."


def attack(attacking,defending):
    if attacking.upper()=="BULBASAUR" and defending.upper()=="CHARMANDER":
        hp_left= round(188-92,1)
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="BULBASAUR" and defending.upper()=="SQUIRTLE":
        hp_left=round(198-(1.1*92), 1)
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="BULBASAUR" and defending.upper()=="BULBASAUR":
        hp_left=0
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="CHARMANDER" and defending.upper()=="SQUIRTLE":
        hp_left=round(198-98,1)
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="CHARMANDER" and defending.upper()=="CHARMANDER":
        hp_left=0
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="CHARMANDER" and defending.upper()=="BULBASAUR":
        hp_left=round(200-(1.1*98), 1)
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="SQUIRTLE" and defending.upper()=="CHARMANDER":
       hp_left=round(188-(1.1*90), 1)
       return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="SQUIRTLE" and defending.upper()=="BULBASAUR":
        hp_left=round(200-90,1)
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    elif attacking.upper()=="SQUIRTLE" and defending.upper()=="SQUIRTLE":
        hp_left=0
        return "{} lowered {}'s hp to {}".format(attacking,defending,hp_left)
    else:
        return "No information on this."
    


def adopt(first_poki, second_poki):
    if first_poki.upper()== "CHARMANDER":
        if second_poki.upper()=="SQUIRTLE":
            return "You adopted {}!".format(first_poki)
        if second_poki.upper()=="BULBASAUR":
            return "You adopted {}!".format(first_poki)
        if second_poki.upper()=="CHARMANDER":
            return "You adopted {}!".format(first_poki)
    elif first_poki.upper()== "BULBASAUR":
         if second_poki.upper()=="SQUIRTLE":
             return "You adopted {}!".format(second_poki)
         if second_poki.upper()=="BULBASAUR":
            return "You adopted {}!".format(first_poki)
         if second_poki.upper()=="CHARMANDER":
            return "You adopted {}!".format(second_poki)
    elif first_poki=="SQUIRTLE":
        if second_poki.upper()=="SQUIRTLE":
             return "You adopted {}!".format(first_poki)
        if second_poki.upper()=="CHARMANDER":
             return "You adopted {}!".format(second_poki)
        if second_poki.upper()=="BULBASAUR":
            return "You adopted {}!".format(first_poki)
    else:
        return "No information on one of these pokemon."
    
