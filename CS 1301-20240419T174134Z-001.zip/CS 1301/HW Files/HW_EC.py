"""
Georgia Institute of Technology - CS1301
Extra Credit HW
"""

__author__ = """ Pelumi Oluleye """
__collab__ = """ I worked on this homework alone only using course materials. """

def date_cruncher(original_dates):
    new_date=[]
    for place in range(len(original_dates)):
        date= original_dates[place]
        info= date.split(" ")
        ahora=""
        if info[0].lower() == "january" or info[0].lower() == "jan":
            month= "01"
            for length in range(len(info[1])):
                if info[1][length]  in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)

        elif info[0].lower() == "february" or info[0].lower() == "feb":
            month= "02"
            for length in range(len(info[1])):
                if info[1][length] in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)

        elif info[0].lower() == "march" or info[0].lower() == "mar":
            month= "03"
            for length in range(len(info[1])):
                if info[1][length] in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora
            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
                   
        elif info[0].lower() == "april" or info[0].lower() == "apr":
            month= "04"
            for length in range(len(info[1])):
                if info[1][length] in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
                   
        elif info[0].lower() == "may" or info[0].lower() == "may":
            month= "05"
            for length in range(len(info[1])):
                if info[1:][length]  in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
         
        elif info[0].lower() == "june" or info[0].lower() == "jun":
            month= "06"
            for length in range(len(info[1])):
                if info[1][length]  in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
           
        elif info[0].lower() == "july" or info[0].lower() == "jul":
            month= "07"
            for length in range(len(info[1])):
                if info[1][length] in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
                  
        elif info[0].lower() == "august" or info[0].lower() == "aug":
            month= "08"
            for length in range(len(info[1])):
                if "123456789" in info[1][length]:
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
           
        elif info[0].lower() == "september" or info[0].lower() == "sept":
            month= "09"
            for length in range(len(info[1])):
                if info[1][length]  in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
       
        elif info[0].lower() == "october" or info[0].lower() == "oct":
            month= "10"
            for length in range(len(info[1])):
                if info[1][length] in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
        elif info[0].lower() == "november" or info[0].lower() == "nov":
            month= "11"
            for length in range(len(info[1])):
                if info[1][length]  in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
            
        elif info[0].lower() == "december" or info[0].lower() == "dec":
            month= "12"
            for length in range(len(info[1])):
                if info[1][length]  in "123456789":
                    ahora= ahora + info[1][length]
            if len(ahora) == 1:
                ahora= "0" + ahora

            reformatted="{}-{}-{}".format(month,ahora,info[2][:])
            new_date.append(reformatted)
    return new_date




def honor_roll(students):
    honor_roll=[]
    highest_honor=[]
    high_honor= []
    org_list=[]
    tup_list=(highest_honor,high_honor,honor_roll)
    for place in range(len(students)):
            tup=students[place]
            name= tup[0]
            grade_list= tup[1]
            num_grade=0
            new_tup=()
            for place in range(len(grade_list)):
                num_grade= num_grade + grade_list[place]                       
                total_grade= num_grade/len(grade_list)
                new_tup= total_grade,tup[0]
                org_list.append(new_tup)
    org_list.sort(reverse=True)   
    for place in range(len(org_list)):
        if org_list[place][0] >= 95:
            highest_honor.append(org_list[place][1])
        elif org_list[place][0] >=90:
            high_honor.append(org_list[place][1])
        elif org_list[place][0] >=80:
            honor_roll.append(org_list[place][1])
    return tup_list



def sum_row(array):
    value=0
    if len(array)==0:
        return value
    elif array[0] >= 0 or array[0] <= 0:
        value= value + array[0]
        return sum_row(array[1:]) + value
    else:
        return sum_row(array[1:])

