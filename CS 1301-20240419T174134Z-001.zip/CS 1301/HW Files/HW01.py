##Georgia Institute of Technology - CS1301
##HW01 - Functions and Statements

##__author__ = """ Pelumi Oluleye """
##__collab__ = """ I worked on this homework assignment alone, using only this semester's course material """

from math import pi
from math import ceil

def groceries():
    apple_quantity = int(input("How many apples would you like?"))
    bananas_quantity = int(input("How many bananas would you like?"))
    peaches_quantity = int(input("How many peaches would you like?"))
    apples_cost = apple_quantity * .50
    bananas_cost= bananas_quantity *.20
    peach_cost= peaches_quantity *.75
    total= apples_cost + bananas_cost + peach_cost
    print("{}​​ apples, {} bananas, and {} peaches costs $​{}."
          .format(apple_quantity,bananas_quantity,peaches_quantity, total))
   
     


def volume_of_donut():
    R = float(input("""What's the outer radius of the donut?"""))
    r= float(input("""What's the inner radius of the donut?"""))
    volume= round((2*pi*R)*(pi*r**2), 3)
    print("A donut with outer radius {} and inner radius {} has a volume of {}."
                .format(R, r, volume))
           

def split_uber():
    distance= float(input("How long was the ride in miles?"))
    surge= float(input("""What's the surge pricing multiplier?"""))
    people= int(input("How many people rode?"))
    tip= float(input("How much would you like to tip your driver?"))
    trip_cost=((distance*.45)*surge)+ tip
    price_per_person = round((trip_cost/people), 2)
    print("Your ride cost $​{}, so the {} riders should each pay $​{}."
          .format(trip_cost, people, price_per_person)) 
          


def cupcake_fan():
    num_cupcakes= int(input("How many vanilla cupcakes do you want to eat today?"))
    num_choc_cakes= int(input("How many chocolate cupcakes do you want to eat today?"))
    vanilla_calories= num_cupcakes*300
    choc_calories= num_choc_cakes*410
    num_miles= ceil((choc_calories + vanilla_calories)/95)
    num_laps= ceil((choc_calories + vanilla_calories)/10)
    print("To burn off {} vanilla cupcakes and {} chocolate cupcakes, you would need to run {} miles or swim {} laps!"
          .format(num_cupcakes, num_choc_cakes, num_miles, num_laps))


def package_eggs():
    num_eggs= int(input("How many eggs do you need to package?"))
    num_grosses= num_eggs//144
    remaining_after_grosses= num_eggs%144
    num_boxes=remaining_after_grosses//36
    remaining_after_boxes=remaining_after_grosses%36
    num_cartons= remaining_after_boxes//12
    remaining_after_cartons=remaining_after_boxes%12
    num_miniCart= remaining_after_cartons//4
    eggs_left= remaining_after_boxes%4
    packing= print("For {} eggs, you will need {} grosses, {} boxes, {} cartons and {} mini-cartons, with {} leftover."
                   .format(num_eggs, num_grosses,num_boxes, num_cartons,num_miniCart, eggs_left)) 




