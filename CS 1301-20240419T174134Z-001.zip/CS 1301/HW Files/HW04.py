
##Georgia Institute of Technology - CS1301
##HW04 - Strings and Lists
##"""
##__author__ = """ Pelumi Oluleye """
##__collab__ = """ I worked on this homework alone using only course materials. """

def reverse_sentence(sentence):
    word_list= sentence.split()
    reverse=''
    for word in word_list[::-1]:
        reverse=reverse + ' ' + word
    return reverse[1:]

def insert_string(sentence,word,index):
    return "{}{}{}".format(word,sentence[0:index+1], sentence[index+1:])


def count_matches(sentence, substring):
    appearance=0
    for place in range(0,len(sentence)+1):
        if sentence[place:place+len(substring)]== substring:
            appearance+=1
    return appearance

        

def list_symmetric(numbers):
    if numbers[::-1]== numbers:
        return True
    elif numbers== "":
        return True
    else:
        return False


def grade_counter(grades,credit,letter):
    count=0
    for place in grades:
        grades_list= place + credit
        if letter=="A" and grades_list<=105 and grades_list>=90:
                count+=1
        elif letter== "B" and grades_list<=89 and grades_list>=80:
                count+=1
        elif letter== "C" and grades_list<=79 and grades_list>=70:
                count+=1
        elif letter== "D" and grades_list<=69 and grades_list>=60:
                count+=1
        elif letter == "F" and grades_list<=59 and grades_list>=0:
                count+=1
    return count
        


def invite_only(linelist, invited):
    final_list=[]
    for name in linelist:
        for place in invited:
            if name.upper()== place.upper():
                final_list.append(name)
                invited.remove(place)
    return final_list



def study_group(students, major):
    matches=[]
    for place in students:
        new_list=place.split(",")
        if new_list[1].strip().upper() == major.upper():
          matches.append(new_list[0])
    return matches
    


def calculate_gpa(class_credits):
    count=0
    points=0
    for place in class_credits:
        if place[0] >=90:
            points+= place[1]*4
            count+=place[1]
        elif place[0] >= 80 and place[0] <=89:
            points+=place[1]*3
            count+=place[1]    
        elif place[0] >= 70 and place[0] <=79:
            points+=place[1]*2
            count+=place[1] 
        elif place[0] >= 60 and place[0] <=69:
            points+=place[1]*1
            count+=place[1] 
        elif place[0] <=59:
            points+=place[1]*0
            count+=place[1] 
    return round((points/count), 2)



