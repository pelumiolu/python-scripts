##Georgia Institute of Technology - CS1301
##HW03 - Iteration

##__author__ = """Pelumi Oluleye"""
##__collab__ = """ I worked on this homework assignment with Trinity Davie and Keah Gruduah using only course materials. """


def count_measures(number):
    for measure in range(1,number+1):
        print("{},2,3,4".format(measure))


def expandWord(string,number):
    new_string=""
    for letter in string:
        for word in range(number):
            new_string= new_string + letter
    return new_string
   


def findMiniWord(word):
    new_string=""
    for index in range(0,len(word)):
        if word[index]== "[":
            first_part= index
        elif word[index] == "]":
                second_part = index
                return word[0:first_part]+ word[(second_part+1):]


def makeRectangle(length, width):
    for measurements in range(1,width+1):
        make=""
        for rectangle in range(length,0,-1):
            make= make + str(rectangle)
        print(make)
               
def howManyEggs(eggs,guess_allowed):
    count=1
    user_guess= int(input("How many eggs do you think there are? "))
    while count <= guess_allowed:
        if user_guess == eggs:
            print("You did it in {} tries!".format(count))
            return True
        else:
            count+=1
            if count<= guess_allowed:
               user_guess= int(input("Wrong answer! Try again: "))
    print("You lost!")
    return False
                

def secret_message(phrase):
    message_list=phrase.split(" ")
    message_unveiled=""
    for length in message_list:
        message_unveiled+=length[0]
    return message_unveiled

def multiplication_table(rows, base):
    num=0
    table=""
    for number in range(1,rows+1):
            num= base*number
            table= str(num)*num
            print(table)
    

def sum_check(numbers, integer):
    total = 0 
    for value in numbers: 
        num = int(value) 
        total += num
    if total== integer:
        return True
    else:
        return False


def string_cleaner(word, fact):
    clean_string=""
    values= "0123456789"
    if fact== False:
        return word
    else:
        for place in word:
            if place not in values:
                clean_string+=place
            else:
                print(place)
                    
        return clean_string
   


    
