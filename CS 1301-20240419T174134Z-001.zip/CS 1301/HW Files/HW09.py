"""
Georgia Institute of Technology - CS1301
HW09 Recursion
"""
__author__ = """ Pelumi Oluleye """
__collab__ = """ I worked on this homework alone only using course materials. """


def count_evens(numbers):
    count=0
    if len(numbers)== 0:
        return 0
    elif numbers == []:
        return 0
    elif float(numbers[0])%2==0:
        count+=1
        return count_evens(numbers[1:])+count
    else:
        return count_evens(numbers[1:])
    

def flatten_list(aList):
    if len(aList)== 0:
        return []
    elif type(aList[0]) == list:
        return flatten_list(aList[0]) + flatten_list(aList[1:])
    else:
        return  [aList[0]] + flatten_list(aList[1:])
   


def num_substrings(string, substring):
    count=0
    if len(string)==0:
        return 0
    elif string[0:len(substring)]== substring:
        count+=1
        return num_substrings(string[1:], substring) + count
    else:
        return num_substrings(string[1:], substring)


def profit(dictionary, brand):
    if brand in dictionary:
        tup= dictionary[brand]
        return tup[0]     
    else:
        for key in dictionary:
            company=profit(dictionary[key][1], brand)
            if type(company)== int or type(company)== float:
                return company
        return "{} could not be found.".format(brand)


def pascal_dictionary(num):
    if num <= 0:
        return {}
    elif num == 1:
        return {1:[1]}
    else:
        previous_dict= pascal_dictionary(num-1)
        dict_value= previous_dict[num-1]
        dict_list=[1]
        for i in range(len(dict_value)-1):
            new_num=dict_value[i] + dict_value[i+1]
            dict_list.append(new_num)
        dict_list.append(1)
        previous_dict[num]=dict_list
        return previous_dict


def minmax(nums):
    if nums == []:
        return ()
    if len(nums)== 1:
        return nums[0],nums[0]
    if len(nums)==2:
        if nums[0]> nums[1]:
            return nums[1],nums[0]
        else:
            return nums[0], nums[1]
    else:
        first_half=minmax(nums[:len(nums)//2])
        second_half= minmax(nums[len(nums)//2:])        
        if first_half[0] < second_half[0]:
            minimum= first_half[0]
        else:
            minimum= second_half[0]
            
        if first_half[1] > second_half[1]:
            maximum= first_half[1]
        else:
            maximum= second_half[1]
        return minimum,maximum
            
            


