"""
Georgia Institute of Technology - CS1301
HW10 - OOP
"""

__author__ = """ Pelumi Oluleye """
__collab__ = """ I worked on this homwework alone only using course materials. """

class Food:

    def __init__(self, name, price, ingredients, food_type, calories):
            self.name= name
            self.price=round(price,2)
            self.ingredients= ingredients
            self.food_type= food_type
            self.calories= calories

    def __eq__(self, other):
        if self.food_type == other.food_type:
            return True
        else:
            return False

    def __str__(self):
        return "{} is a {} that costs ${}.".format(self.name,self.food_type,self.price)


    def __repr__(self):
        return f"{self.name}: {self.price}: {self.food_type}: {self.calories}"

class Menu:
    def __init__(self, appetizer_list, entree_list, dessert_list):
        self.appetizer_list= appetizer_list
        self.entree_list = entree_list
        self.dessert_list= dessert_list
        self.total_items=len(appetizer_list)+ len(entree_list)+ len(dessert_list)

    def delete_items(self, foods):
        count=0
        for comida in foods:
                if comida in self.appetizer_list:
                    count+=1
                    index= self.appetizer_list.index(comida)
                    del self.appetizer_list[index]
                elif comida in self.entree_list:
                    count+=1
                    index= self.entree_list.index(comida)
                    del self.entree_list[index]
                elif comida in self.entree_list:
                    count+=1
                    index= self.entree_list.index(comida)
                    del self.entree_list[index]
                  
        self.total_items=self.total_items-count            
        if count == len(foods):
            return count,True
        else:
            return count,False

    def add_items(self, foods):
        count=0
        for comida in foods:
            if comida not in self.appetizer_list:
                count+=1
                self.appetizer_list.append(comida)
                self.total_items+=1
            elif comida not in self.entree_list:
                count+=1
                self.entree_list.append(comida)
                self.total_items+=1
            elif comida not in self.dessert_list:
                count+=1
                self.dessert_list.append(comida)
                self.total_items+=1
        return "You have added {} items to your menu. Your menu now contains {} total items.".format(count,self.total_items)


    def __str__(self):
       return "There are {} items on the menu. Appetizers are {}. Entrees are {}. Desserts are {}.".format(self.total_items,self.appetizer_list,self.entree_list,self.dessert_list) 


    def __repr__(self):
        return f"Menu: {self.total_items} items"

class Customer:
    def __init__(self, name, wallet, is_vegetarian, allergies, server):
        self.name= name
        self.wallet= round(float(wallet),2)
        self.is_vegetarian = is_vegetarian
        self.allergies= allergies
        self.server= server

    def place_order(self, foods, menu):
        count=0
        for comida_t in foods:
            for ingr in comida_t.ingredients:
                if self.wallet < comida_t.price and ingr not in self.allergies:
                    count+=1
                    self.wallet= self.wallet-comida_t.price
        if count == len(foods):
            return True
        else:
            return False
       
    def change_servers(self, new_server):
        self.server.total_tips= self.server.total_tips-5
        location = self.server.customer_list.index(self)
        del self.server.customer_list[location]
        new_server.customer_list.append(self)
        new_server.total_tips= new_server.total_tips+5
        self.server=new_server


    def give_tip(self, tip):
        self.server.total_tips= (self.server.total_tips+ tip)
        self.wallet= self.wallet- tip
        place= self.server.customer_list.index(self)
        del self.server.customer_list[place]

    def __str__(self):
         return "{} has ${} and has allergies to {}. Server is {}".format(self.name,self.wallet,self.allergies,self.server.name)

    def __repr__(self):
         return f"{self.name}: ${self.wallet}, {self.is_vegetarian}, {self.allergies}, {self.server.name}"

class Server:

    def __init__(self, name, customer_list, restaurant):
        self.name= name
        self.customer_list=customer_list
        self.restaurant= restaurant
        self.total_tips=0

        


    def done_serving(self, customers):
        for people in customers:
                if people not in self.customer_list:
                    self.customer_list.append(people)
                else:
                    place= self.customer_list.index(people)
                    del self.customer_list[place]
        return  "{} still has {} customers waiting to be served.".format(self.name, len(self.customer_list)) 

    def __str__(self):
        return "{} is a server.".format(self.name)

 
    def __repr__(self):
        return f"server: {self.name}, tips: {self.total_tips}, restaurant: {self.restaurant}"
