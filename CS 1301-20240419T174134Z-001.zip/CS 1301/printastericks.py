##Write a function called print_asterisks that takes a number
##as a parameter and prints out that many asterisks using recursion.
##All the asterisks should be on the same line.
##
##You may not use a loop.
##
##Upload your code here when you have it working in idle.
##It does not matter what you name the .py file.

def print_astericks(num):
    newstring=""
    if num ==0:
        return 0
    else:
        print_astericks(num-1)
        newstring+="*"
    print(newstring, end="")



    

 
