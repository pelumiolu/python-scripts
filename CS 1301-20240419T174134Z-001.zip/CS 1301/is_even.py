def is_even(num):
    if num%2==0:
        return True
    else:
        return False

def double_num(num):
    if is_even(num):
        return num*2
    else:
        return num*3
