def get_dollars(quarters,dimes,nickels,pennies):
    q=quarters*.25
    d=dimes*.10
    n=nickels*.05
    p=pennies*.01
    dollars= round((q+d+n+p),2)
    print("${}".format(dollars))
