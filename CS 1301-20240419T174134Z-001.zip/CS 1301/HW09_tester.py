import unittest
from pathlib import Path
import importlib



"""
HW 09 Student Tester - Fall 2018
"""

__author__ = "1301 TAs"
__version__ = 2.0

class TestMyClass(unittest.TestCase):

    error_messages = {}
    maxDiff = None

    @classmethod
    def set_hw(cls, hw):
        cls.hw = hw

    def test_author(self):
        self.error_messages["author"] = "Missing or empty __author__ global variable."
        self.assertTrue(self.hw.__author__, msg=self.error_messages["author"])
        del self.error_messages["author"]

    def test_collab(self):
        self.error_messages["collab"] = "Missing or empty __collab__ global variable."
        self.assertTrue(self.hw.__collab__, msg=self.error_messages["collab"])
        del self.error_messages["collab"]

    def test_count_evens_1(self):
        func = "count_evens"
        params = [4,53,1203,66,1,4,90.0,8]
        ans = 5
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.count_evens(params),
                         msg=message)
    def test_count_evens_2(self):
        func = "count_evens"
        params = []
        ans = 0
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.count_evens(params),
                         msg=message)

    def test_flatten_list_1(self):
        func = "flatten_list"
        params = [1, 5, [[], [], False], [], [[]], 'hi']
        ans = [1, 5, False, 'hi']
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.flatten_list(params),
                         msg=message)

    def test_flatten_list_2(self):
        func = "flatten_list"
        params = [False, True, False, False]
        ans = [False, True, False, False]
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.flatten_list(params),
                         msg=message)

    def test_num_substrings_1(self):
        func = "num_substrings"
        params = 'hello hello hello', 'el'
        ans = 3
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.num_substrings(*params),
                         msg=message)

    def test_num_substrings_2(self):
        func = "num_substrings"
        params = 'axabxacxadxa', 'x'
        ans = 4
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.num_substrings(*params),
                         msg=message)

    def test_profit_1(self):
        func = "profit"
        params = {"Georgia Tech": (231298.22, {"Buzz": (100,{}), "Ramblin Wreck": (200, {} )})}, "Buzz"
        ans = 100
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.profit(*params),
                         msg=message)


    def test_profit_2(self):
        func = "profit"
        params = {"Georgia Tech": (231298.22, {"Buzz": (100, {}), "Ramblin Wreck": (200, {} )})}, "Tic Tac"
        ans = "Tic Tac could not be found."
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.profit(*params),
                         msg=message)


    def test_pascal_dictionary_1(self):
        func = "pascal_dictionary"
        params = 3
        ans = {1: [1], 2: [1, 1], 3: [1, 2, 1]}
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.pascal_dictionary(params),
                         msg=message)

    def test_pascal_dictionary_2(self):
        func = "pascal_dictionary"
        params = 7
        ans = {1: [1], 2: [1, 1], 3: [1, 2, 1], 4: [1, 3, 3, 1], 5: [1, 4, 6, 4, 1], 6: [1, 5, 10, 10, 5, 1], 7: [1, 6, 15, 20, 15, 6, 1]}
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.pascal_dictionary(params),
                         msg=message)

    def test1_minmax(self):
        func = "minmax"
        params = [1519, 176, 1377, 1217, 269, 808, 896, 1519, 287, 252, 506]
        ans = (176,1519)
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.minmax(params),
                         msg=message)


    def test2_minmax(self):
        func = "minmax"
        params = [89, 18, -65, 32, 98, 59]
        ans = (-65, 98)
        message = "Failed {}{} expected '{}'.".format(func, params, ans)
        self.assertEqual(ans, self.hw.minmax(params),
                         msg=message)


    def test_zeta_error_messages(self):
        """function to compile all errors into one place."""
        errors = [self.error_messages[key] for key in self.error_messages]
        errors_msg = "\n".join(errors)
        self.assertEqual(
            {},
            self.error_messages,
            msg=f'\n\nMissed Tests:\n{errors_msg}'
        )

# imports the student's hw and runs it through the unittests


def run(student_file):
    hw = importlib.import_module(student_file.with_suffix("").name)
    TestMyClass.set_hw(hw)

    print("starting tester")
    with Path("out.txt").open(mode="w") as f:
        runner = unittest.TextTestRunner(f)
        unittest.main(testRunner=runner, exit=False)
    print("sucessfully ran, check out.txt")


# when a python script is run directly (not through import), then it's __name__
# is main and as such should do something. for us, that's testing the hw by
# calling run


if __name__ == "__main__":
    student_file = Path("HW09.py")
    if student_file.exists is False:
        print("Cannot find student's homework file. Make sure it's in the same"
              " folder and is named {}.".format(student_file.name))
    else:
        run(student_file)



