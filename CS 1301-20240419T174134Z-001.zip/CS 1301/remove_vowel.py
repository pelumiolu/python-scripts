def remove_vowels():
    newstring=""
    for letter not in "aeiouAEIOU":
            newstring += letter
            return newstring
#you cnnot remove anything you can only create new
