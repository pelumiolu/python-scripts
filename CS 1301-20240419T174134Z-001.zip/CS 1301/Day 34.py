#Day 34- finishing up object
from teachermodule import Teacher,Student
joey= Student("Joseph", 3.3)
joe= Student("Joseph", 3.3)
burns= Teacher("Mr.Burns", 10)
burnsy= Teacher("Mr.Burns", 10)

print(joey== joe)
print(burns==burnsy)

if (joey> tommmy):
    print(Joey!)
else:
    print("Tom rocks!")
