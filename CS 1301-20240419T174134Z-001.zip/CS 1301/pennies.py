def get_seconds(hours, minutes, seconds):
    hours= 
    seconds=
    minutes=
print("{} seconds".format(get_seconds(5, 25, 12)))
