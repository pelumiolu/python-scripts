def  compute_circle_area(radius):
        area= 3.14157*radius**2
        print(area)
compute_circle_area(1)
compute_circle_area(100)









