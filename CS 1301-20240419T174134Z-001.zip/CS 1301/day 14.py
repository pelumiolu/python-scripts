#Day 14 - List cloning and aliasing
#lists are stored differently than primitive variables
#the variable name is only reference to where the list is stored - not a stored value



#aliasing
alist=[1,2,3]
blist=[4,5,6]
clist= alist  #point to the same memory location
alist.append(99)
clist.append(99)
print(list)  
dlist = blist   #same memory location
dlist.append(88)
clist.append(88)
print(len(alist))
print(len(blist))

#cloning (copying)
aalist=[1,2,3]
bblist=[4,5,6]
cclist=aalist[:] #copy every element

#nested lists contain pointers to the smaller list within them

#chapter 14, list algorithms
#max and min
#find the most common item

mylist= [1,2,4,2,3,2,4,5]
largest_count=0
which_item=mylist[0]
for item in mylist:
    itemcount=0
    for item2 in mylist:
        if item2== item:
            itemcount+=1
    if itemcount > largest_count:
        largest_count=itemcount
        which_item= item
print("{} is the most common with this many occureances".format(which_item, largest_count)

def count_common(lista, listb):
    count=0
    location=0
    for place in listb:
        if list[place]== listb[place]
    return location+= place
            count+= 1
      

      
