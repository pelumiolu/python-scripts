#Day 13- Advanced Lists
grades= [77,88, 99,87,100]

if 100 in grades:
    print("good class")
#highest grade (Find)
highest_so_far= grade #standard way to do it
for grade in grades:
    if grade > highest_so_far:
        highest_so_far = grade
#del is deleting from a list

#nested lists
    products = [["1-2","2-2"]["55-1","552","55-3"]]
    print len

def getList(list):
        newlist=[]
        for smallList in list:
            for item in smallList:
                newList.append(item)
        return newlist


