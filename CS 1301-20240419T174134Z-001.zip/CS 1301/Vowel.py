#Day 30 OOP
#lists and strings are classes (They have methods)
['joe' 'tom', 'bill'] #is an object crated as an instance of the list class
"Melinda" #is an object created as an instance of the string class

#a class is a specific category of data type which allows for methods and attributes

print(myname.lower()) #I can use the lower method because myname is a string object



#creating your own class
class Pet: #it is customary to capitalize the name of the class
    def __init__(self, aname, akind):
        self.name= aname
        self.kind= akind
    def speak(self):
        if self.kind=="dog":
            print("Woof")
        else:
            print("Meow")
pet1= Pet('Beauty', 'cat') #creates an object of the Pet class called pet1
print(type(pet1))
pet1.speak()



    
def hasVowel(string):
    if len(string) == 0:
        return False
    elif string[0].lower() in "aeiou":
        return True
    else:
        return hasVowel(string[1:])
