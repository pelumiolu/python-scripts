class Teacher: 
    def __init__(self,aname, akind):
        self.name= aname
        self.kind= akind
    def __str__(self):
        return "{} teaches grade {}".format(self.name,self.kind)
    def move_up(self):
        if self.kind in range(1,4):
            self.kind+= 1
        elif self.kind in range(5,13):
            self.kind += 2



