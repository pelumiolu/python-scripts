def form_groups(filename, current_student, num_per_team):
    top = 0
    ranking = []
    linelist = []
    linelist1 = []
    studentlist = []
    try:
        readfile = open(filename, 'r')
        writefile = open('group.txt', 'w')
        linelist = readfile.readlines()
        for line in linelist:
            line = line.replace('\n', '')
            linelist1.append(line)
        for line1 in linelist1:
            if "Test" not in line1:
                line1 = line1.split(', ')
                if line1 != ['']:
                    studentlist.append(tuple(line1))
        if num_per_team == 1:
            writefile.write("Team " + current_student)
        elif num_per_team != 0:
            writefile.write("Team " + current_student)
            for student, avg in get_all_averages(filename).items():
                for first, last in studentlist:
                    if student == first:
                        student = first + " " + last
                ranking.append((avg, student))
                ranking.sort(reverse= True)
            for avg, student in ranking:
                d = student.find(' ')
                if student[:d] in current_student:
                    ranking.remove((avg, student))
            if num_per_team - 1 <= len(ranking):
                for ind in range(num_per_team - 1):
                    writefile.write('\n' + str(ind+1) + ') ' + ranking[ind][1])
            else:
                for ind in range(len(ranking)):
                    writefile.write('\n' + str(ind+1) + ') ' + ranking[ind][1])
        readfile.close()
        writefile.close()
    except FileNotFoundError:
        return "File is not found."
