##Write a complete function called nickname that takes a name (a string) in a parameter and returns the first three letters of the name followed by a period. 
##
##for example
##
##print(nickname("Erica"))
##
##will print out
##
##Eri.

def nickname(name):
    return(name[0:3]+".")
