def nickname(name, number):
    count=1
    for value in range(number):s
        new_name= name[value]*count
        count+=1
        return new_name
