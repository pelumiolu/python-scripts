##f1= open("poem.txt", "r")
##f2=open("short_poem.txt", "w")
##lines=f1.readlines()
##for num in range(0, len(lines)):
##    lines[num]= lines[num].replace("e", "")
##    f2.write(lines[num])
##f1.close()
##f2.close()

#download the csv file
f=open("crime_data.csv", "r")
linelist= f.readlines()
for i in range(5):
    templist= linelist[i].split(",")
    print(templist)
f.close()

##Day 27: advanced csv files
#did district one or two have more crime?
f= open("crime_data.csv","r")
headings=f.readline()
data= f.readlines()
count1=0
count2=0
for line in data:
    line=line.split(",")
    if line[1]== "1":
        count1+=1
    elif line[1]== "2":
        count2+= 1
if count1> count2:
    print("District 1 is more crime-ridden")
elif count1<count2:
    print("District 2 is more crime-ridden")
else:
    print("Both districts are the same")
    

##which district has the most crime
f= open("crime_data.csv","r")
headings=f.readline()
data= f.readlines()
count1=0
count2=0
d={}
## line[1] is the district as a string
for line in data:
    line=line.split(",")
    if line[1] in d:
        d[line[1]]+=1
        count1+=1
    else:
        d[line[1]]=1
highest=0
for key,value in d.items():
    if value>highest:
        highest=value
        highdistrict=key
    print("District 1 has the most crime".format(highdistrict))
f.close()

#Recursion
#a different way of repeating, instead of using a loop
#a function just keeps calling itself which makes it starts all over again

#must have a base case
##must call itself
# each time it starts over, it must be closer to the base case

def countdown(num):
    if num==0:
        print("stop")
    else:
        print(num)
        countdown(num-1)
countdown(10)

def evens(num):
    if num<=0:
        pass
    else:
        if num%2==1:
            evens(num-1)
        else:
            print(num)
            evens(num-2)
evens(19)

##try this...
def count_number(num):
    if num==0:
        return 0
    else:
        return (num+count_number(num-1))
count_number(10)

