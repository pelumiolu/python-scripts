# day 32 (Teacher & Student classes that interact)


class Teacher:
    def __init__ (self,n="",g=1):# name and grade get their values from the parameter list
                           # but coworkers and students are initialized to []
        self.coworkers = []  # a list of other Teachers
        self.students = []
        self.name = n
        self.grade = g

    def __str__(self):
        return self.name + " has " + str(len(self.coworkers)) + " coworkers."

    def move_up(self):
        if self.grade in [1,2,3]:
            self.grade += 1
        elif self.grade in range(4,13):
            self.grade += 2
        else:
            pass
        
    def get_coworker(self,t):
        self.coworkers.append(t)

    def show_coworkers(self):
        for item in self.coworkers:
            print(item.name)

class Student:
    def __init__(self,n="",gp=0.0):
        self.name = n
        self.gpa = gp
        self.teachers = []
    def __str__(self):
        return self.name
    def __eq__(self,other):
        if self.name == other.name and self.gpa == other.gpa:
            return True
        else:
            return False


























    
